<?php
    define('HOST','localhost');
	define('USER','bsdbukgr_jaff');
	define('PASS','bsdbukgr_jaff');
	define('DB','bsdbukgr_jaff');
	$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
 
?>